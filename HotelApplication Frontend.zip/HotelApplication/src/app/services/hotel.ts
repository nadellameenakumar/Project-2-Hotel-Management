export class BookingModel {

    status?:String;
    room_id?:number;
    user_id?:number;

}